Changelog
=========

## 0.1.0 (2017-01-01)

Initial release.

### Features

* Positions a popup so that the whole content is visible without moving the map.
* Available on npmjs.
* Limitation: tips are not drawn.

## 0.2.0 (2017-01-08)

* Implement tips.
* Popup have tips by default.